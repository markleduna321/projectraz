

<?php $__env->startSection('title', 'Deatails for ' . $inventory->name); ?>

<?php $__env->startSection('content'); ?>
<div class="input-group">
    <h1> Deatails for "<?php echo e($inventory->name); ?>" </h1>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventory-delete')): ?>
     <span class="input-group-btn" style="position:relative;left:20px;">
    <form action="<?php echo e(route('inventory.destroy', ['inventory' => $inventory])); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>

        <button type="submit" class="btn btn-danger"> Delete </button>
    </form>
    </span>
    <?php endif; ?>
</div>
 </br>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventory-edit')): ?>
         
                    <a href="<?php echo e(route('inventory.edit', ['inventory' => $inventory])); ?>"> 
                    <button class="btn btn-primary">Update</button></a>
           
        <?php endif; ?>
                   
        <input type="button" onclick="printDiv('print-content')" value="Print" class="btn btn-success"/>
        <div id="print-content">
 <br>       
            <div class="input-group">
       <div class="input-group">
            <div class="form-group pb-2">
            <label for="name">Account Name:</label>
            <input type="text" name="name" value="<?php echo e($inventory->name); ?>" readonly style="width:300px;" class="form-control">
            <div><?php echo e($errors->first('name')); ?></div>
            </div>
        <span class="input-group-btn" style="position:relative;left:520px;">
            <div class="form-group pb-2">
            <label for="date">Date:</label>
            <input type="date" name="date" value="<?php echo e($inventory->date); ?>" readonly style="width:300px;" class="form-control">
            <div><?php echo e($errors->first('date')); ?></div>
            </div>
        </span>
        </div>
            <div class="form-group pb-2">
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo e($inventory->address); ?>" readonly style="width:600px;" class="form-control">
            <div><?php echo e($errors->first('address')); ?></div>
            </div>
        </div>
        <input type="hidden" name="status" value="Completed">
            <input type="hidden" name="id" value="<?php echo e($inventory->id); ?>">
        <table border="3" cellpadding="0" cellspacing="0" class="table table-bordered"   >
        <tr>
        <th style=" background-color:#4CAF50;width:20%;text-align:center"> Product </th>
        <th style=" background-color:#4CAF50;width:10%;text-align:center">END INV</th>
        <th style=" background-color:#4CAF50;width:10%;text-align:center">New Delivery</th>
        <th style=" background-color:#4CAF50;width:10%;text-align:center">DR/INV #</th>
        <th style=" background-color:#4CAF50;width:5%;text-align:center">Total Stocks</th>
        <th style=" background-color:#4CAF50;width:5%;text-align:center">Stocks On Hand</th>
        <th style=" background-color:#4CAF50;width:5%;text-align:center">Stocks Sold</th>
        <th style=" background-color:#4CAF50;width:10%;text-align:center">Price</th>
        <th style=" background-color:#4CAF50;width:15%;text-align:center">Amount</th>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product); ?></td>
        <td><?php echo e($inventory->endinv); ?></td>
        <td><?php echo e($inventory->newdel); ?></td>
        <td><?php echo e($inventory->invnum); ?></td>
        <td><?php echo e($inventory->totalstock); ?></td>
        <td><?php echo e($inventory->stockleft); ?></td>
        <td><?php echo e($inventory->stocksold); ?></td>
        <td><?php echo e($inventory->price); ?></td>
        <td><?php echo e($inventory->amount); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product2); ?></td>
        <td><?php echo e($inventory->endinv2); ?></td>
        <td><?php echo e($inventory->newdel2); ?></td>
        <td><?php echo e($inventory->invnum2); ?></td>
        <td><?php echo e($inventory->totalstock2); ?></td>
        <td><?php echo e($inventory->stockleft2); ?></td>
        <td><?php echo e($inventory->stocksold2); ?></td>
        <td><?php echo e($inventory->price2); ?></td>
        <td><?php echo e($inventory->amount2); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product3); ?></td>
        <td><?php echo e($inventory->endinv3); ?></td>
        <td><?php echo e($inventory->newdel3); ?></td>
        <td><?php echo e($inventory->invnum3); ?></td>
        <td><?php echo e($inventory->totalstock3); ?></td>
        <td><?php echo e($inventory->stockleft3); ?></td>
        <td><?php echo e($inventory->stocksold3); ?></td>
        <td><?php echo e($inventory->price3); ?></td>
        <td><?php echo e($inventory->amount3); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product4); ?></td>
        <td><?php echo e($inventory->endinv4); ?></td>
        <td><?php echo e($inventory->newdel4); ?></td>
        <td><?php echo e($inventory->invnum4); ?></td>
        <td><?php echo e($inventory->totalstock4); ?></td>
        <td><?php echo e($inventory->stockleft4); ?></td>
        <td><?php echo e($inventory->stocksold4); ?></td>
        <td><?php echo e($inventory->price4); ?></td>
        <td><?php echo e($inventory->amount4); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product5); ?></td>
        <td><?php echo e($inventory->endinv5); ?></td>
        <td><?php echo e($inventory->newdel5); ?></td>
        <td><?php echo e($inventory->invnum5); ?></td>
        <td><?php echo e($inventory->totalstock5); ?></td>
        <td><?php echo e($inventory->stockleft5); ?></td>
        <td><?php echo e($inventory->stocksold5); ?></td>
        <td><?php echo e($inventory->price5); ?></td>
        <td><?php echo e($inventory->amount5); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product6); ?></td>
        <td><?php echo e($inventory->endinv6); ?></td>
        <td><?php echo e($inventory->newdel6); ?></td>
        <td><?php echo e($inventory->invnum6); ?></td>
        <td><?php echo e($inventory->totalstock6); ?></td>
        <td><?php echo e($inventory->stockleft6); ?></td>
        <td><?php echo e($inventory->stocksold6); ?></td>
        <td><?php echo e($inventory->price6); ?></td>
        <td><?php echo e($inventory->amount6); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product7); ?></td>
        <td><?php echo e($inventory->endinv7); ?></td>
        <td><?php echo e($inventory->newdel7); ?></td>
        <td><?php echo e($inventory->invnum7); ?></td>
        <td><?php echo e($inventory->totalstock7); ?></td>
        <td><?php echo e($inventory->stockleft7); ?></td>
        <td><?php echo e($inventory->stocksold7); ?></td>
        <td><?php echo e($inventory->price7); ?></td>
        <td><?php echo e($inventory->amount7); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product8); ?></td>
        <td><?php echo e($inventory->endinv8); ?></td>
        <td><?php echo e($inventory->newdel8); ?></td>
        <td><?php echo e($inventory->invnum8); ?></td>
        <td><?php echo e($inventory->totalstock8); ?></td>
        <td><?php echo e($inventory->stockleft8); ?></td>
        <td><?php echo e($inventory->stocksold8); ?></td>
        <td><?php echo e($inventory->price8); ?></td>
        <td><?php echo e($inventory->amount8); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product9); ?></td>
        <td><?php echo e($inventory->endinv9); ?></td>
        <td><?php echo e($inventory->newdel9); ?></td>
        <td><?php echo e($inventory->invnum9); ?></td>
        <td><?php echo e($inventory->totalstock9); ?></td>
        <td><?php echo e($inventory->stockleft9); ?></td>
        <td><?php echo e($inventory->stocksold9); ?></td>
        <td><?php echo e($inventory->price9); ?></td>
        <td><?php echo e($inventory->amount9); ?></td>
        </tr>

        <tr style=" background-color:white;">
        <td><?php echo e($inventory->product10); ?></td>
        <td><?php echo e($inventory->endinv10); ?></td>
        <td><?php echo e($inventory->newdel10); ?></td>
        <td><?php echo e($inventory->invnum10); ?></td>
        <td><?php echo e($inventory->totalstock10); ?></td>
        <td><?php echo e($inventory->stockleft10); ?></td>
        <td><?php echo e($inventory->stocksold10); ?></td>
        <td><?php echo e($inventory->price10); ?></td>
        <td><?php echo e($inventory->amount10); ?></td>
        </tr>

        <tr>
        <th colspan="8" style="text-align:center"> Total: </th>
        <th><?php echo e($inventory->total); ?></th>
        </tr>

        </table>
       </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/inventory/show.blade.php ENDPATH**/ ?>