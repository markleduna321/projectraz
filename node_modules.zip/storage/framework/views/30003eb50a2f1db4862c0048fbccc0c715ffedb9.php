

<?php $__env->startSection('title', 'Edit Details for ' . $account->name); ?>

<?php $__env->startSection('content'); ?>
    <h1> Edit Details for <?php echo e($account->name); ?> </h1>

    <form action="<?php echo e(route('account.update', ['account' => $account])); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
        <?php echo method_field('PATCH'); ?>
        <?php echo $__env->make('account.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        <button type="submit" class="btn btn-primary">Save account</button>

    </form>

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/account/edit.blade.php ENDPATH**/ ?>