

<?php $__env->startSection('title', 'Deatails for ' . $account->name); ?>

<?php $__env->startSection('content'); ?>
    <h1> Deatails for <?php echo e($account->name); ?> </h1>

    <p><a href="<?php echo e(route('account.edit', ['account' => $account])); ?>"> Edit </a></p>
    <form action="<?php echo e(route('account.destroy', ['account' => $account])); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>

        <button type="submit" class="btn btn-danger"> Delete </button>
    </form>
<br>
      <p><b>Name: </b><?php echo e($account->name); ?> </p>
            
      <p><b>Address: </b><?php echo e($account->address); ?></p>
            
      <p><b> Type: </b> <?php echo e($account->type); ?></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/account/show.blade.php ENDPATH**/ ?>