

<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>
    
    <h1> Accounts </h1>
    <p><a href="<?php echo e(route('account.create')); ?>"> <button class="btn btn-primary">Add Account</button> </a></p>


    <table class="table table-bordered">

        <thead>
            <tr>
               <th> Account Name</th>
                <th>Address</th>
               <th> Type</th>    
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

               <td><a href="<?php echo e(route('account.show', ['account' => $account])); ?>"><?php echo e($account->name); ?></a></td>
                <td><?php echo e($account->address); ?></td>
               <td> <?php echo e($account->type); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/account/index.blade.php ENDPATH**/ ?>