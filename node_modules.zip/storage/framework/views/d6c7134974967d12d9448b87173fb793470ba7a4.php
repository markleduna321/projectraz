

<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>
    <h1> Contact Us </h1>

    
        <form action="/contact" method="POST">

    <div class="form-group pb-3">
            <label for="name">Name:</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control">
            <div><?php echo e($errors->first('name')); ?></div>
        </div>
            
        <div class="form-group pb-3">
            <label for="email">Email:</label>
            <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
            <div><?php echo e($errors->first('email')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="message">Message:</label>
            <textarea name="message" id="message" value="<?php echo e(old('message')); ?>" cols="30" rows="10" class="form-control"></textarea>
            <div><?php echo e($errors->first('message')); ?></div>
        </div>

        <?php echo csrf_field(); ?>
        
        <button type="submit" class="btn btn-primary">Send Message</button>

    </form>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/contact/create.blade.php ENDPATH**/ ?>