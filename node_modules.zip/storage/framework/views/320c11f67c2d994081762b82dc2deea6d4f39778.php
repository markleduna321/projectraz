


<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('inventory.store')); ?>" method="POST" enctype="multipart/form-data" class="pb-3">

        <?php echo $__env->make('inventory.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
            
        <button type="submit" class="btn btn-primary">Send Request</button>

    </form>
    <hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/inventory/create.blade.php ENDPATH**/ ?>