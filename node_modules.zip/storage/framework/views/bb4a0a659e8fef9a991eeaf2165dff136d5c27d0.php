


<?php $__env->startSection('content'); ?>

            <h1> Inventory </h1>
    
    

<table class="table table-bordered">

        <thead>
            <tr>
               <th>Inventory ID</th>
                <th>Account Name</th>
               <th> DATE/TIME</th> 
               <th> User</th>  
               <th> Type</th>   
               <th> Status</th>   
               <th> Action</th>    
            </tr>
        </thead>

        <tbody>

             <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <td> <?php echo e($inventory->id); ?> </td>
                <td>
                <?php if(!empty(Auth::user()->getRoleNames())): ?>
                    <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($inventory->status === 'Processed'): ?>
                        <?php echo e($inventory->name); ?>

                        <?php elseif($inventory->user_email === Auth::user()->email or $v === 'Admin'): ?>
                        <a href="<?php echo e(route('inventory.show', ['inventory' => $inventory])); ?>"><?php echo e($inventory->name); ?></a>
                        <?php else: ?>
                        <?php echo e($inventory->name); ?>

                        <?php endif; ?>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </td>
                <td> <?php echo e($inventory->created_at); ?> </td>
                <td> <?php echo e($inventory->user_email); ?> </td>
                <td> <?php echo e($inventory->type); ?> </td>
                
                
                <?php if($inventory->status === 'Completed'): ?>
                <td class="btn-success">
                    <?php echo e($inventory->status); ?></a></td>
                <?php else: ?>
                    <td class=" btn-warning">
                    <?php echo e($inventory->status); ?></a></td>
                <?php endif; ?>
                
                <td>
                
                <?php if(!empty(Auth::user()->getRoleNames())): ?>
                        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v === 'Staff' or $v === 'Admin' and $inventory->status === 'Processed'): ?>

                            <a href="<?php echo e(route('inventory.edit', ['inventory' => $inventory])); ?>"> 
                            <button class="btn btn-primary">Complete Process </button></a>

                        <?php elseif($v === 'Staff' or $v === 'Admin' and $inventory->status === 'Completed'): ?>

                            <button class="btn btn-primary disabled">Complete Process </button>
                        
                        <?php else: ?>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                </td>
            </tr>
             
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>

    <!-- Pagination Link -->
    <?php echo e($inventories->links('pagination::bootstrap-4')); ?>


    <!-- Page Auto Reload -->
    <script>
    function autoRefresh()
    {
        window.location = window.location.href;
    }
     setInterval('autoRefresh()', 600000);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/inventory/index.blade.php ENDPATH**/ ?>