

<?php $__env->startSection('title', 'Edit Details for ' . $inventory->name); ?>

<?php $__env->startSection('content'); ?>
    <h1> Completing Order #<?php echo e($inventory->id); ?> </h1>
<br>
    <form action="<?php echo e(route('inventory.update', ['inventory' => $inventory])); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
        <?php echo method_field('PATCH'); ?>
        <?php echo $__env->make('inventory.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        <button type="submit" class="btn btn-primary">Finish Order</button>

    </form>

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/inventory/edit.blade.php ENDPATH**/ ?>