

<?php $__env->startSection('title', 'Request'); ?>

<?php $__env->startSection('content'); ?>

        <h1> Request Orders </h1>
        <br>

    <!-- New Request Link -->
    <?php if(!empty(Auth::user()->getRoleNames())): ?>
        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($v === 'User'): ?>
                <a href="<?php echo e(route('purchase.create')); ?>">
                <button class="btn btn-warning">
                    Send Request (New)
                </button>
                </a>
            <?php else: ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- New Request Link End -->

    <!-- Current/Update Request Link -->
    <?php if(!empty(Auth::user()->getRoleNames())): ?>
        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($v === 'User'): ?>
                <a href="<?php echo e(route('reqcurrent.create')); ?>">
                <button class="btn btn-primary">
                    Send Request (Current)
                </button>
                </a>
            <?php else: ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- Current/update Request Link End -->

    <!-- Accept Link -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accept-create')): ?>
        <a class="btn btn-success" href="<?php echo e(route('accept.create')); ?>"> Accept Request </a>
    <?php endif; ?>
    <!-- Accept Link End -->

     <br>
     <br>

    <!-- Table -->
    <table class="table table-bordered">
        <!-- Table Head -->
        <thead>
            <tr>
               <th>Purchase ID</th>
               <th>Account Name</th>
               <th> Address</th> 
               <th> Contact #</th>  
               <th> Type</th>       
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty(Auth::user()->getRoleNames())): ?>
                    <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($purchase->user_email === Auth::user()->email or $v === 'Admin' or $v === 'Staff'): ?>
                        <tr>
                        <td> <?php echo e($purchase->id); ?> </td>
                        <td> <?php echo e($purchase->name); ?> </td>
                        <td> <?php echo e($purchase->address); ?> </td>
                        <td> <?php echo e($purchase->contact); ?> </td>
                        <?php if($purchase->status === "Pending"): ?>
                            <td class="btn-warning"> <?php echo e($purchase->status); ?> </td>
                        <?php elseif($purchase->status === "Processed"): ?>
                            <td class="btn-primary"> <?php echo e($purchase->status); ?> </td>
                        <?php elseif($purchase->status === "Completed"): ?>
                            <td class="btn-success"> <?php echo e($purchase->status); ?> </td>
                        <?php endif; ?>
                        
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->

    <!-- Pagination Link -->
    <?php echo e($purchases->links('pagination::bootstrap-4')); ?>


    <!-- Page Auto Reload -->
    <script>
    function autoRefresh()
    {
        window.location = window.location.href;
    }
     setInterval('autoRefresh()', 600000);
    </script>
<?php $__env->stopSection(); ?>
                       
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/purchase/index.blade.php ENDPATH**/ ?>