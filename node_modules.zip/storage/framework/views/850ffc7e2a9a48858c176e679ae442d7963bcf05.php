[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\User\projectraz\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>