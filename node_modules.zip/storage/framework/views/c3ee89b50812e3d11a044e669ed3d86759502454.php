    <?php echo csrf_field(); ?>
       <div class="form-group pb-3">
            <label for="name">Account Name:</label>
            <input type="text" name="name" value="<?php echo e(old('name') ?? $account->name); ?>" class="form-control">
            <div><?php echo e($errors->first('name')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="address">Address:</label>
            <input type="address" name="address" value="<?php echo e(old('address') ?? $account->address); ?>" class="form-control">
            <div><?php echo e($errors->first('address')); ?></div>
        </div>

        <div class="form-group pb-3">
            <label for="type">Type:</label>
            <select name="type" id="type" class="form-control">
                    <option value="<?php echo e(old('type') ?? $account->type); ?>"> <?php echo e(old('type') ?? $account->type); ?> </option>
                    <option value="Hospital"> Hospital </option>
                    <option value="Pharmacy"> Pharmacy </option>
            </select>
            <div><?php echo e($errors->first('type')); ?></div>
        </div><?php /**PATH C:\Users\User\projectraz\resources\views/account/form.blade.php ENDPATH**/ ?>