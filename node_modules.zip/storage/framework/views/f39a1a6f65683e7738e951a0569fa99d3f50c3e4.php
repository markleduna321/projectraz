

<?php $__env->startSection('title', 'Add New Order'); ?>

<?php $__env->startSection('content'); ?>

    <h1> Request Order (Current/Update)</h1>
    <br>

    <div class="form-group pb-3">
        <form action="/searchcurr" method="get">
            <label for="search">Generate PO Data:</label>
            <div class="input-group">
                <input type="search" name="search" class="form-control">
                    <span class="input-group-btn">
                        <button type="submit" class="btn btn-primary">Generate</button>
                    </span>
            </div>
        </form>    
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
               <th>Order ID</th>
                <th>Account Name</th>
               <th> Date</th>   
               <th> Type</th>    
            </tr>
        </thead>

        <tbody>
             <?php $__currentLoopData = $lemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($lemon->user_email === Auth::user()->email): ?>    
                    <tr>
                        <td><?php echo e($lemon->id); ?></td>
                        <td><?php echo e($lemon->name); ?></a></td>
                        <td><?php echo e($lemon->updated_at); ?></td>
                        <td><?php echo e($lemon->type); ?></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Pagination Link -->
    <?php echo e($lemons->links('pagination::bootstrap-4')); ?>


    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/reqcurrent/create.blade.php ENDPATH**/ ?>