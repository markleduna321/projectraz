

<?php $__env->startSection('title', 'New Request'); ?>

<?php $__env->startSection('content'); ?>

    <h1> Request Order (New)</h1>
    <br>

    <!-- Search Account -->
    <div class="form-group pb-3">
        <form action="/search" method="get">
            <label for="search">Generate Account Data:</label>
            <div class="input-group">
                <select name="search" class="form-control">
                <option value=""> </option>
                 <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($account->name); ?>"> <?php echo e($account->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="input-group-btn">
                    <button type="submit" class="btn btn-primary">Generate</button>
                </span>
            </div>
        </form>    
    </div>
    <!-- Search Account End -->
    
    <!-- Save Form -->
    <form action="<?php echo e(route('purchase.store')); ?>" method="POST" enctype="multipart/form-data" class="pb-3">

        <!-- Form Inputs -->
        <?php echo $__env->make('purchase.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <br>
        <button type="submit" class="btn btn-primary">Send Request</button>

    </form>

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/purchase/create.blade.php ENDPATH**/ ?>