

<?php $__env->startSection('title', 'Add New Customer'); ?>

<?php $__env->startSection('content'); ?>

    <h1> Request Order (Current/Update) </h1>
    <br>

    <form action="<?php echo e(route('reqcurrent.store')); ?>" method="POST" enctype="multipart/form-data" class="pb-3">
        <?php $__currentLoopData = $inventories->slice(0,1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php echo csrf_field(); ?>
       
            <input type="hidden" name="user_email" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
            <div><?php echo e($errors->first('user_email')); ?></div>

            <input type="hidden" name="orderid" value="<?php echo e($inventory->orderid); ?>" class="form-control">
            <div><?php echo e($errors->first('orderid')); ?></div>

            <div class="form-group pb-2">
            <label for="name">Account Name:</label>
            <input type="text" name="name" value="<?php echo e($inventory->name); ?>" readonly class="form-control">
            <div><?php echo e($errors->first('name')); ?></div>
            </div>
        
            <div class="form-group pb-2">
            <label for="date">Date:</label>
            <input type="text" name="date" value="<?php echo e($inventory->updated_at); ?>" readonly class="form-control">
            <div><?php echo e($errors->first('date')); ?></div>
            </div>
        
            <div class="form-group pb-2">
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo e($inventory->address); ?>" readonly class="form-control">
            <div><?php echo e($errors->first('address')); ?></div>
            </div>

            <div class="form-group pb-3">
            <input type="hidden" name="type" value="<?php echo e($inventory->type); ?>" class="form-control">
            <div><?php echo e($errors->first('type')); ?></div>
            </div>

            <div class="form-group pb-3">
            <label for="conact">Contact Person:</label>
            <input type="text" name="contact" value="<?php echo e(old('contact')); ?> " class="form-control">
            <div><?php echo e($errors->first('contact')); ?></div>
            </div>

            <div class="form-group pb-3">
            <label for="phone">Contact #:</label>
            <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control">
            <div><?php echo e($errors->first('phone')); ?></div>
            </div>

            <div class="form-group pb-3">           
            <input type="hidden" name="status" value="Pending" class="form-control" readonly>
            <div><?php echo e($errors->first('status')); ?></div>
            </div>
       
    <table border="3" cellpadding="0" cellspacing="0" class="table table-bordered">
        <tr>
            <th style=" background-color:#4CAF50; width:40%;">Product</th>
            <th style=" background-color:#4CAF50; width:10%;">END INV</th>
            <th style=" background-color:#4CAF50; width:25%;">QTY</th>
            <th style=" background-color:#4CAF50; width:25%;">Price</th>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid" value="<?php echo e($inventory->prodid); ?>" readonly>
        <?php if(is_null($inventory->product)): ?>
            <select name="product" id="product" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
            <input type="text" style="border:0;" class="form-control" name="product" value="<?php echo e($inventory->product); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv" value="<?php echo e($inventory->stockleft); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid2" value="<?php echo e($inventory->prodid2); ?>" readonly>
        <?php if(is_null($inventory->product2)): ?>
            <select name="product2" id="product2" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
            <input type="text" style="border:0;" class="form-control" name="product2" value="<?php echo e($inventory->product2); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv2" value="<?php echo e($inventory->stockleft2); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount2" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price2" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid3" value="<?php echo e($inventory->prodid3); ?>" readonly>
        <?php if(is_null($inventory->product3)): ?>
            <select name="product3" id="product3" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product3" value="<?php echo e($inventory->product3); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv3" value="<?php echo e($inventory->stockleft3); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount3" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price3" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid4" value="<?php echo e($inventory->prodid4); ?>" readonly>
        <?php if(is_null($inventory->product4)): ?>
            <select name="product4" id="product4" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product4" value="<?php echo e($inventory->product4); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv4" value="<?php echo e($inventory->stockleft4); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount4" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price4" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid5" value="<?php echo e($inventory->prodid5); ?>" readonly>
        <?php if(is_null($inventory->product5)): ?>
            <select name="product5" id="product5" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product5" value="<?php echo e($inventory->product5); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv5" value="<?php echo e($inventory->stockleft5); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount5" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price5" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid6" value="<?php echo e($inventory->prodid6); ?>" readonly>
        <?php if(is_null($inventory->product6)): ?>
            <select name="product6" id="product6" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product6" value="<?php echo e($inventory->product6); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv6" value="<?php echo e($inventory->stockleft6); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount6" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price6" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid7" value="<?php echo e($inventory->prodid7); ?>" readonly>
        <?php if(is_null($inventory->product7)): ?>
            <select name="product7" id="product7" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product7" value="<?php echo e($inventory->product7); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv7" value="<?php echo e($inventory->stockleft7); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount7" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price7" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid8" value="<?php echo e($inventory->prodid8); ?>" readonly>
        <?php if(is_null($inventory->product8)): ?>
            <select name="product8" id="product8" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product8" value="<?php echo e($inventory->product8); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv8" value="<?php echo e($inventory->stockleft8); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount8" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price8" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid9" value="<?php echo e($inventory->prodid9); ?>" readonly>
        <?php if(is_null($inventory->product9)): ?>
            <select name="product9" id="product9" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product9" value="<?php echo e($inventory->product9); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv9" value="<?php echo e($inventory->stockleft9); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount9" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price9" value=""></td>
        </tr>

        <tr style=" background-color:white;">
        <td>
        <input type="hidden" style="border:0; font-size:16px;" name="prodid10" value="<?php echo e($inventory->prodid10); ?>" readonly>
        <?php if(is_null($inventory->product10)): ?>
            <select name="product10" id="product10" style="border:0;" class="form-control">
                <option value=""></option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
        <input type="text" style="border:0;" class="form-control" name="product10" value="<?php echo e($inventory->product10); ?>" readonly>
        <?php endif; ?>
        </td>
        <td><input type="number" style="border:0;" class="form-control" name="endinv10" value="<?php echo e($inventory->stockleft10); ?>" readonly></td>
        <td><input type="number" style="border:0;" class="form-control" name="amount10" value=""></td>
        <td><input type="number" style="border:0;" class="form-control" name="price10" value=""></td>
        </tr>

    </table>
          
    <br>
    
    <button type="submit" class="btn btn-primary">Send Request</button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
    
    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/reqcurrent/current.blade.php ENDPATH**/ ?>