    
    <?php echo csrf_field(); ?>

    <!-- Echo Accounts -->
    <?php $__currentLoopData = $accounts->slice(0,1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <!-- user email hidden -->
        <input type="hidden" name="user_email" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
        <div><?php echo e($errors->first('user_email')); ?></div>

        <!-- order ID hidden -->
        <input type="hidden" name="orderid" value="<?php echo e($account->id); ?>" class="form-control">
        <div><?php echo e($errors->first('orderid')); ?></div>

        <!-- Account Name -->
        <div class="form-group pb-3">
            <label for="name">Account Name:</label>
            <input type="text" name="name" value="<?php echo e($account->name); ?>" class="form-control">
            <div><?php echo e($errors->first('name')); ?></div>
        </div>

        <!-- Address -->
        <div class="form-group pb-3">
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo e($account->address); ?>" class="form-control">
            <div><?php echo e($errors->first('address')); ?></div>
        </div>

        <!-- Type(hospital/pharma hidden) -->
        <div class="form-group pb-3">
            <input type="hidden" name="type" value="<?php echo e($account->type); ?>" class="form-control">
            <div><?php echo e($errors->first('type')); ?></div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Echo Accounts End -->
        
        <!-- Contact Person -->
        <div class="form-group pb-3">
            <label for="conact">Contact Person:</label>
            <input type="text" name="contact" value="<?php echo e(old('contact')); ?>" autocomplete="off" class="form-control">
            <div><?php echo e($errors->first('contact')); ?></div>
        </div>

        <!-- Contact # -->
        <div class="form-group pb-3">
            <label for="phone">Contact #:</label>
            <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" autocomplete="off" class="form-control">
            <div><?php echo e($errors->first('phone')); ?></div>
        </div>

        <!-- Status hidden -->
        <div class="form-group pb-3">
            <input type="hidden" name="status" value="Pending" class="form-control" readonly>
            <div><?php echo e($errors->first('status')); ?></div>
        </div>

        <!-- Table -->
        <table width="50%" border="3" cellpadding="0" cellspacing="0" class="table table-bordered"   > 
        
            <!-- Table Head -->
            <thead>
                <tr>
                    <th style=" background-color:#4CAF50; width:55%;">Product</th>
                    <th style=" background-color:#4CAF50;">QTY</th>
                    <th style=" background-color:#4CAF50;">Price</th>
                </tr>
            </thead>
            <!-- Table Head End -->

            <!-- Table Body -->
            <tbody>
                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid')); ?></div>
                        <select name="product" id="product" style="border:0;" class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid2" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid2')); ?></div>
                        <select name="product2" id="product2" style="border:0; " class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount2" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price2" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid3" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid3')); ?></div>
                        <select name="product3" id="product3" style="border:0; " class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount3" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price3" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid4" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid4')); ?></div>
                        <select name="product4" id="product4" style="border:0; "class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount4" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price4" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid5" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid5')); ?></div>
                        <select name="product5" id="product5" style="border:0; "class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount5" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price5" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid6" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid6')); ?></div>
                        <select name="product6" id="product6" style="border:0; "class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount6" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price6" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid7" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid7')); ?></div>
                        <select name="product7" id="product7" style="border:0; "class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount7" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price7" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid8" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid8')); ?></div>
                        <select name="product8" id="product8" style="border:0; "class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount8" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price8" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid9" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid9')); ?></div>
                        <select name="product9" id="product9" style="border:0; "class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount9" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price9" value=""class="form-control"></td>
                </tr>

                <tr style=" background-color:white;">
                    <td>
                        <input type="hidden" name="prodid10" value="0" class="form-control">
                        <div><?php echo e($errors->first('prodid10')); ?></div>
                        <select name="product10" id="product10" style="border:0; "class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->product); ?>"> <?php echo e($product->product); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td><input type="number" style="border:0; " name="amount10" value=""class="form-control"></td>
                    <td><input type="number" style="border:0; " name="price10" value=""class="form-control"></td>
                </tr>
            </tbody>
            <!-- Table Body End -->

        </table>
        <!-- Table End -->
<?php /**PATH C:\Users\User\projectraz\resources\views/purchase/form.blade.php ENDPATH**/ ?>