<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                        <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item active">
                          <a class="nav-link" href=""> <strong>Raz Pharmaceuticals</strong> <span class="sr-only">(current)</span></a>
                        </li>
                        

                        <?php else: ?>
                        <li class="nav-item active">
                          <a class="nav-link" href=""> <strong>Raz Pharmaceuticals</strong> <span class="sr-only">(current)</span></a>
                        </li>

                        <!-- Admin/Staff access -->
                        <?php if(!empty(Auth::user()->getRoleNames())): ?>
                        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v === 'Admin' or $v === 'Staff'): ?>

                            <li class="nav-item active">
                            <a class="nav-link" href="/products">Products</a>
                            </li>
                        
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <!-- admin access only -->
                        <?php if(!empty(Auth::user()->getRoleNames())): ?>
                        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v === 'Admin'): ?>

                        <li class="nav-item active">
                          <a class="nav-link" href="/users"> Manage Users <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item active">
                          <a class="nav-link" href="/roles"> Manage Roles <span class="sr-only">(current)</span></a>
                        </li>

                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <!-- Admin/Staff/User access -->
                        <?php if(!empty(Auth::user()->getRoleNames())): ?>
                        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v === 'Admin' or $v === 'Staff' or $v === 'User'): ?>

                            <li class="nav-item active">
                            <a class="nav-link" href="/inventory"> Inventory </a>
                            </li>
                            <li class="nav-item active">
                            <a class="nav-link" href="/purchase">Purchase Order</a>
                            </li>
                            
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <!-- Admin/Staff/Investor access -->
                        <?php if(!empty(Auth::user()->getRoleNames())): ?>
                        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v === 'Admin' or $v === 'Staff' or $v === 'Investor'): ?>

                            <li class="nav-item active">
                            <a class="nav-link" href="/reports">Reports</a>
                            </li>
                        
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <!-- Staff/User access -->
                        <?php if(!empty(Auth::user()->getRoleNames())): ?>
                        <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v === 'Staff' or $v === 'User'): ?>

                            <li class="nav-item active ">
                            <a class="nav-link" href="/account">Accounts</a>
                            </li>

                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                          
                        <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                
                            </li>
                            
                        <?php else: ?>
                            <li class="">
                                <a href="/home" class="dropdown-item">
                                    <?php echo e(Auth::user()->name); ?> 
                                </a>
                            </li>
|
                            <li>
                                <div class="" aria-labelledby="">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav><?php /**PATH C:\Users\User\projectraz\resources\views/nav.blade.php ENDPATH**/ ?>