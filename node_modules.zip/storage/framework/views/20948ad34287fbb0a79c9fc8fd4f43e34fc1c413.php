<?php echo e($slot); ?>

<?php /**PATH C:\Users\User\projectraz\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>