


<?php $__env->startSection('content'); ?>

            <h1> Reports </h1>
    
    <!-- New Report Link -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports-create')): ?>
        <a class="btn btn-success" href="<?php echo e(route('reports.create')); ?>"> Add New Report </a>
    <?php endif; ?>
    
    <br>
    <br>

    <table class="table table-bordered table-dark table-hover ">
        <thead>
            <tr>
                <th style="width: 250px">Annual Net Income</th>
                <td style="text-align: center"><?php echo e($annualnetincome); ?></td>
            </tr>
        </thead>
    </table>

    <div class="table-responsive">
        <h3>Month of January</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
               <th>Month</th>
               <th>Account Name</th>
               <th>Gross Income</th>
               <th> Pharmacy</th> 
               <th> Pharmacist</th>  
               <th> Doctor</th>
               <th> Allocated Budget</th>
               <th> Expenses</th>   
               <th> Building</th>
               <th> Total</th>
               <th> Capital</th>  
               <th> Total Deduction</th>  
               <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $january; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($jan->created_at->format('M - Y')); ?> </td>
                    <td><?php echo e($jan->accountname); ?></td>
                    <td> <?php echo e($jan->grossinc); ?> </td>
                    <td> (<?php echo e($jan->pharmacypercent); ?>) <?php echo e($jan->pharmacy); ?></td>
                    <td> (<?php echo e($jan->pharmacistpercent); ?>) <?php echo e($jan->pharmacist); ?></td>
                    <td> (<?php echo e($jan->doctorpercent); ?>) <?php echo e($jan->doctor); ?></td>
                    <td> (<?php echo e($jan->allocatedbudgetpercent); ?>) <?php echo e($jan->allocatedbudget); ?></td>   
                    <td> (<?php echo e($jan->expensespercent); ?>) <?php echo e($jan->expenses); ?></td>
                    <td> (<?php echo e($jan->buildingpercent); ?>) <?php echo e($jan->building); ?></td>  
                    <td> (<?php echo e($jan->deductionpercent); ?>) <?php echo e($jan->deduction); ?></td>   
                    <td> <?php echo e($jan->capital); ?></td>  
                    <td> <?php echo e($jan->totaldeduction); ?></td>  
                    <td> <?php echo e($jan->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($jannet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>

<br>

    <div class="table-responsive">
        <h3>Month of February</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
               <th>Month</th>
               <th>Account Name</th>
               <th>Gross Income</th>
               <th> Pharmacy</th> 
               <th> Pharmacist</th>  
               <th> Doctor</th>
               <th> Allocated Budget</th>
               <th> Expenses</th>   
               <th> Building</th>
               <th> Total</th>
               <th> Capital</th>  
               <th> Total Deduction</th>  
               <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $february; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($feb->created_at->format('M - Y')); ?> </td>
                    <td><?php echo e($feb->accountname); ?></td>
                    <td> <?php echo e($feb->grossinc); ?> </td>
                    <td> (<?php echo e($feb->pharmacypercent); ?>) <?php echo e($feb->pharmacy); ?></td>
                    <td> (<?php echo e($feb->pharmacistpercent); ?>) <?php echo e($feb->pharmacist); ?></td>
                    <td> (<?php echo e($feb->doctorpercent); ?>) <?php echo e($feb->doctor); ?></td>
                    <td> (<?php echo e($feb->allocatedbudgetpercent); ?>) <?php echo e($feb->allocatedbudget); ?></td>   
                    <td> (<?php echo e($feb->expensespercent); ?>) <?php echo e($feb->expenses); ?></td>
                    <td> (<?php echo e($feb->buildingpercent); ?>) <?php echo e($feb->building); ?></td>  
                    <td> (<?php echo e($feb->deductionpercent); ?>) <?php echo e($feb->deduction); ?></td>   
                    <td> <?php echo e($feb->capital); ?></td>  
                    <td> <?php echo e($feb->totaldeduction); ?></td>  
                    <td> <?php echo e($feb->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($febnet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>

<br>

    <div class="table-responsive">
        <h3>Month of March</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
               <th>Month</th>
               <th>Account Name</th>
               <th>Gross Income</th>
               <th> Pharmacy</th> 
               <th> Pharmacist</th>  
               <th> Doctor</th>
               <th> Allocated Budget</th>
               <th> Expenses</th>   
               <th> Building</th>
               <th> Total</th>
               <th> Capital</th>  
               <th> Total Deduction</th>  
               <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $march; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($mar->created_at->format('M - Y')); ?> </td>
                    <td> <?php echo e($mar->accountname); ?></td>
                    <td> <?php echo e($mar->grossinc); ?> </td>
                    <td> (<?php echo e($mar->pharmacypercent); ?>) <?php echo e($mar->pharmacy); ?></td>
                    <td> (<?php echo e($mar->pharmacistpercent); ?>) <?php echo e($mar->pharmacist); ?></td>
                    <td> (<?php echo e($mar->doctorpercent); ?>) <?php echo e($mar->doctor); ?></td>
                    <td> (<?php echo e($mar->allocatedbudgetpercent); ?>) <?php echo e($mar->allocatedbudget); ?></td>   
                    <td> (<?php echo e($mar->expensespercent); ?>) <?php echo e($mar->expenses); ?></td>
                    <td> (<?php echo e($mar->buildingpercent); ?>) <?php echo e($mar->building); ?></td>  
                    <td> (<?php echo e($mar->deductionpercent); ?>) <?php echo e($mar->deduction); ?></td>   
                    <td> <?php echo e($mar->capital); ?></td>  
                    <td> <?php echo e($mar->totaldeduction); ?></td>  
                    <td> <?php echo e($mar->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($marchnet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>

<br>

    <div class="table-responsive">
        <h3>Month of April</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
            <th>Month</th>
            <th>Account Name</th>
            <th>Gross Income</th>
            <th> Pharmacy</th> 
            <th> Pharmacist</th>  
            <th> Doctor</th>
            <th> Allocated Budget</th>
            <th> Expenses</th>   
            <th> Building</th>
            <th> Total</th>
            <th> Capital</th>  
            <th> Total Deduction</th>  
            <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $april; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($apr->created_at->format('M - Y')); ?> </td>
                    <td><?php echo e($apr->accountname); ?></td>
                    <td> <?php echo e($apr->grossinc); ?> </td>
                    <td> (<?php echo e($apr->pharmacypercent); ?>) <?php echo e($apr->pharmacy); ?></td>
                    <td> (<?php echo e($apr->pharmacistpercent); ?>) <?php echo e($apr->pharmacist); ?></td>
                    <td> (<?php echo e($apr->doctorpercent); ?>) <?php echo e($apr->doctor); ?></td>
                    <td> (<?php echo e($apr->allocatedbudgetpercent); ?>) <?php echo e($apr->allocatedbudget); ?></td>   
                    <td> (<?php echo e($apr->expensespercent); ?>) <?php echo e($apr->expenses); ?></td>
                    <td> (<?php echo e($apr->buildingpercent); ?>) <?php echo e($apr->building); ?></td>  
                    <td> (<?php echo e($apr->deductionpercent); ?>) <?php echo e($apr->deduction); ?></td>   
                    <td> <?php echo e($apr->capital); ?></td>  
                    <td> <?php echo e($apr->totaldeduction); ?></td>  
                    <td> <?php echo e($apr->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($aprilnet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>

<br>

    <div class="table-responsive">
        <h3>Month of May</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
            <th>Month</th>
            <th>Account Name</th>
            <th>Gross Income</th>
            <th> Pharmacy</th> 
            <th> Pharmacist</th>  
            <th> Doctor</th>
            <th> Allocated Budget</th>
            <th> Expenses</th>   
            <th> Building</th>
            <th> Total</th>
            <th> Capital</th>  
            <th> Total Deduction</th>  
            <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $may; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($my->created_at->format('M - Y')); ?> </td>
                    <td><?php echo e($my->accountname); ?></td>
                    <td> <?php echo e($my->grossinc); ?> </td>
                    <td> (<?php echo e($my->pharmacypercent); ?>) <?php echo e($my->pharmacy); ?></td>
                    <td> (<?php echo e($my->pharmacistpercent); ?>) <?php echo e($my->pharmacist); ?></td>
                    <td> (<?php echo e($my->doctorpercent); ?>) <?php echo e($my->doctor); ?></td>
                    <td> (<?php echo e($my->allocatedbudgetpercent); ?>) <?php echo e($my->allocatedbudget); ?></td>   
                    <td> (<?php echo e($my->expensespercent); ?>) <?php echo e($my->expenses); ?></td>
                    <td> (<?php echo e($my->buildingpercent); ?>) <?php echo e($my->building); ?></td>  
                    <td> (<?php echo e($my->deductionpercent); ?>) <?php echo e($my->deduction); ?></td>   
                    <td> <?php echo e($my->capital); ?></td>  
                    <td> <?php echo e($my->totaldeduction); ?></td>  
                    <td> <?php echo e($my->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($maynet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>

<br>

    <div class="table-responsive">
        <h3>Month of June</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
            <th>Month</th>
            <th>Account Name</th>
            <th>Gross Income</th>
            <th> Pharmacy</th> 
            <th> Pharmacist</th>  
            <th> Doctor</th>
            <th> Allocated Budget</th>
            <th> Expenses</th>   
            <th> Building</th>
            <th> Total</th>
            <th> Capital</th>  
            <th> Total Deduction</th>  
            <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $june; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($jun->created_at->format('M - Y')); ?> </td>
                    <td><?php echo e($jun->accountname); ?></td>
                    <td> <?php echo e($jun->grossinc); ?> </td>
                    <td> (<?php echo e($jun->pharmacypercent); ?>) <?php echo e($jun->pharmacy); ?></td>
                    <td> (<?php echo e($jun->pharmacistpercent); ?>) <?php echo e($jun->pharmacist); ?></td>
                    <td> (<?php echo e($jun->doctorpercent); ?>) <?php echo e($jun->doctor); ?></td>
                    <td> (<?php echo e($jun->allocatedbudgetpercent); ?>) <?php echo e($jun->allocatedbudget); ?></td>   
                    <td> (<?php echo e($jun->expensespercent); ?>) <?php echo e($jun->expenses); ?></td>
                    <td> (<?php echo e($jun->buildingpercent); ?>) <?php echo e($jun->building); ?></td>  
                    <td> (<?php echo e($jun->deductionpercent); ?>) <?php echo e($jun->deduction); ?></td>   
                    <td> <?php echo e($jun->capital); ?></td>  
                    <td> <?php echo e($jun->totaldeduction); ?></td>  
                    <td> <?php echo e($jun->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($junenet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>

<br>

    <div class="table-responsive">
        <h3>Month of July</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
            <th>Month</th>
            <th>Account Name</th>
            <th>Gross Income</th>
            <th> Pharmacy</th> 
            <th> Pharmacist</th>  
            <th> Doctor</th>
            <th> Allocated Budget</th>
            <th> Expenses</th>   
            <th> Building</th>
            <th> Total</th>
            <th> Capital</th>  
            <th> Total Deduction</th>  
            <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $jully; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($jul->created_at->format('M - Y')); ?> </td>
                    <td><?php echo e($jul->accountname); ?></td>
                    <td> <?php echo e($jul->grossinc); ?> </td>
                    <td> (<?php echo e($jul->pharmacypercent); ?>) <?php echo e($jul->pharmacy); ?></td>
                    <td> (<?php echo e($jul->pharmacistpercent); ?>) <?php echo e($jul->pharmacist); ?></td>
                    <td> (<?php echo e($jul->doctorpercent); ?>) <?php echo e($jul->doctor); ?></td>
                    <td> (<?php echo e($jul->allocatedbudgetpercent); ?>) <?php echo e($jul->allocatedbudget); ?></td>   
                    <td> (<?php echo e($jul->expensespercent); ?>) <?php echo e($jul->expenses); ?></td>
                    <td> (<?php echo e($jul->buildingpercent); ?>) <?php echo e($jul->building); ?></td>  
                    <td> (<?php echo e($jul->deductionpercent); ?>) <?php echo e($jul->deduction); ?></td>   
                    <td> <?php echo e($jul->capital); ?></td>  
                    <td> <?php echo e($jul->totaldeduction); ?></td>  
                    <td> <?php echo e($jul->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($jullynet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>

<br>

    <div class="table-responsive">
        <h3>Month of August</h3>
    <!-- Table -->
    <table class="table table-striped table-dark table-hover ">
        <!-- Table Head -->
        <thead>
            <tr>
            <th>Month</th>
            <th>Account Name</th>
            <th>Gross Income</th>
            <th> Pharmacy</th> 
            <th> Pharmacist</th>  
            <th> Doctor</th>
            <th> Allocated Budget</th>
            <th> Expenses</th>   
            <th> Building</th>
            <th> Total</th>
            <th> Capital</th>  
            <th> Total Deduction</th>  
            <th> Net Income</th>
            </tr>
        </thead>
        <!-- Table Head End -->

        <!-- Table Body -->
        <tbody>
            <?php $__currentLoopData = $august; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($aug->created_at->format('M - Y')); ?> </td>
                    <td><?php echo e($aug->accountname); ?></td>
                    <td> <?php echo e($aug->grossinc); ?> </td>
                    <td> (<?php echo e($aug->pharmacypercent); ?>) <?php echo e($aug->pharmacy); ?></td>
                    <td> (<?php echo e($aug->pharmacistpercent); ?>) <?php echo e($aug->pharmacist); ?></td>
                    <td> (<?php echo e($aug->doctorpercent); ?>) <?php echo e($aug->doctor); ?></td>
                    <td> (<?php echo e($aug->allocatedbudgetpercent); ?>) <?php echo e($aug->allocatedbudget); ?></td>   
                    <td> (<?php echo e($aug->expensespercent); ?>) <?php echo e($aug->expenses); ?></td>
                    <td> (<?php echo e($aug->buildingpercent); ?>) <?php echo e($aug->building); ?></td>  
                    <td> (<?php echo e($aug->deductionpercent); ?>) <?php echo e($aug->deduction); ?></td>   
                    <td> <?php echo e($aug->capital); ?></td>  
                    <td> <?php echo e($aug->totaldeduction); ?></td>  
                    <td> <?php echo e($aug->netincome); ?></td>  
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="12">Total Net Income</td>
                    <td><?php echo e($augnet); ?></td>
                </tr>
        </tbody>
        <!-- Table Body End -->
    </table>
    <!-- Table End -->
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\projectraz\resources\views/reports/index.blade.php ENDPATH**/ ?>