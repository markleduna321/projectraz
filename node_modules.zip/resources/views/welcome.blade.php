@extends('layouts.app')

@section('title', 'About')

@section('content')
    <h1> home </h1>
@endsection