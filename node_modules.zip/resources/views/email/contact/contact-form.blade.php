@component('mail::message')

@endcomponent
